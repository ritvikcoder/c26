Step1- Add salt to 4 to 5 cups of water and bring it to rapid boil.
Step2- Then add pasta, and boil it till it is almost cooked(not toattaly cooked).
Step3- Drain the water and let the pasta cool down.
Step4- Put oil on a pan and wait until it is hot.
Step5- Add the vegetables and saute till it become slightly crunchy.
Step6- Take another pan and add finely chopped garlic(optional).
Step7- Add butter then saute for a minute.
Step8- Add flour and mix it.
Step9- Lower the flame and add 1/4 cup milk and mix it (you have to ensure that there are no lumps and you can add more milk if needed only after all the lumps are gone).
Step10- Cook till it sauce slightly thickens.
Step11- Add cheese as much as you want or you can skip it too.
Step12- Add oregano and pepper.
Step13- Add salt if needed.
Step14- Add the pasta and vegetables to the sauce and mix well and let it cook for a min.
Step15- Garnish the pasta will chilli flakes and pepper.
        And your pasta is ready to be served.