Pasta
Chopped Vegetables of your choice(like corns,capsicum,carrot etc)
Butter
Garlic
Flour
Milk
Cheese
Black pepper
Oregano
Chilli flakes(optional)
Salt(as per your taste)


